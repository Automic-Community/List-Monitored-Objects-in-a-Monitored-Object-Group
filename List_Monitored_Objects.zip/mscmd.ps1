﻿# Variables to be configured

# Management Server host ID
$ms_host = "vmstm2k870"

# Communication Server port number
$ms_port = 9900

# Management Server Service Name
$ms_service_name = "sldmgts"

# User credentials for connecting to Management Server
$user_login = "admin"
$user_password = "sysload"

# -----------------------------------------------------------------------------

function sldms_query()
{
	param($url)
	
	#Write-Host $url

	$lines_returned = @()
	
	# This function sends a query to Management Server
	# It returns an array of strings
	
	$webclient = new-object net.webclient
	
	$lines  = $webclient.DownloadString($url)
	
	$line_array = $lines.split("`n")
	
	foreach($line in $line_array)
	{
		if($line)
		{
			$lines_returned += $line
		}
	}
	
	$lines_returned
	
	#Ne marche pas pour enlever la dernière ligne blanche et le header éventuel
#	$line_array = $line_array | Select-String -Pattern "^[0-9].*"
#	
#	$line_array

} # function sldms_query()

# -----------------------------------------------------------------------------

function sldms_get_mo_hashtable()
{
	param($agent_type, $agent_name, $mo_name)
	
	# This function returns a hastable for a Managed Object
	# The hashtable also contain a string with a sugested notation for the MO
	
	# sldms_get_mo_hashtable -agent_type xxx -agent_name xxx -mo_name xxx
	
	$mo_hashtable = @{}
	
	$mo_hashtable.mo_name = $mo_name
	$mo_hashtable.agent_name = $agent_name
	$mo_hashtable.agent_type = $agent_type
	
	if($mo_name -eq "")
	{
		$fullname = $agent_name
	}
	else
	{
		$fullname = "{0}@{1}" -f $mo_name, $agent_name
	}

	$mo_hashtable.mo_notation = "{0} ({1})" -f $fullname, $agent_type
	
	$mo_hashtable
}

# -----------------------------------------------------------------------------

function sldms_get_mo_array()
{
	param($mo_list)
	
	# This function returns an array of hashtables from a Managed Objects list in the format received by Management Server API
	
	$mo_array = @()
	
	$mos = $mo_list.split(",")
		
	foreach($mo in $mos)
	{
		$mo_hash = @{}
		$mo_fields = @()
		
		$mo_fields = $mo.split(";")

		$agent_type = $mo_fields[0]
		$agent_name = $mo_fields[1]
		$mo_name = $mo_fields[2]
		
		$mo_hashtable = sldms_get_mo_hashtable -agent_type $agent_type -agent_name $agent_name -mo_name $mo_name
		
		$mo_array += $mo_hashtable
		
	}

	$mo_array

} # function decode_mo_list()

# -----------------------------------------------------------------------------

function sldms_get_group_mo_list()
{
	param($mo_group_class_name, $mo_group_name)
	
	# Get Managed Objects members of a given MO Group
	# Returns an array of hashtables

	$mo_array = @()

	$url = "http://{0}:{1}/services/{2}/sldapi/api_execute?method=agtgrouplist&showagents=1&username={3}&password={4}&outputformat=csv&showheader=0" -f $ms_host, $ms_port, $ms_service_name, $user_login, $user_password

	$lines = sldms_query -url $url

	##;class;name;desc;capproc;capmem;capdisc;capnet;agtcount;agents
	#1;zone;zone_sde;;0.00;0.00;0.00;0.00;0;;
	#2;category;dummy;;0.00;0.00;0.00;0.00;0;;
	#3;category;Support;;0.00;0.00;0.00;0.00;1;"NT;metis;";
	#4;system;os400;;0.00;0.00;0.00;0.00;1;"AS;Dark54_v5r3;";
	#5;system;oracle;;0.00;0.00;0.00;0.00;1;"OBAS;ariane-c-lx26-x64;Clark";
	#6;category;demo frame matrix;All LPARs of the frame Matrix;40.00;0.00;0.00;0.00;5;"POWERVM;matrix53;Server-9408-M25-SN65234C2,UNIX;asterix;,UNI
	#X;matrix71;,UNIX;vioserver;,UNIX;matrix61;";
	
	foreach($line in $lines)
	{
		if(-not $line) # Make sure to ignore blank lines
		{
			continue
		}
		
		$line = $line.split("""")
		
		$group_columns = $line[0]
		$mo_list = $line[1]
		
		$mo_group_fields = $group_columns.split(";")
		$group_class_name = $mo_group_fields[1]
		$group_name = $mo_group_fields[2]
		
		if(($group_class_name -eq $mo_group_class_name) -and ($group_name -eq $mo_group_name))
		{
			# We are on the searched MO Group
			$mo_array = sldms_get_mo_array -mo_list $mo_list
			break;
			
		}

	}
	
	$mo_array
	
} # function sldms_get_group_mo_list()

# -----------------------------------------------------------------------------

function sldms_declare_new_mos()
{

	param($agent_hostids, $agent_port_nos)
	
	# This function declares new Managed Objects from one or more Agents
	
	$url = "http://{0}:{1}/services/{2}/sldapi/api_execute?method=agtdiscover&username={3}&password={4}&hosts={5}&ports={6}&overwrite=1&showheader=0&outputformat=csv" -f $ms_host, $ms_port, $ms_service_name, $user_login, $user_password, $agent_hostids, $agent_port_nos

	$lines = sldms_query -url $url
	
	##;type;name;instance;version;status;message;host;port;histactivityhost;histactivityport;histactivitypath;histeventhost;histeventport;histeventpath;eventmodelhost;eventmodelport;eventmodelpath;inipath;entityinipath;scriptfilepath;logfilepath;authfilepath
	#1;NT;frlpmsys01;;v5.34;1;;FRLPMSYS01;9501;FRLPMSYS01;9502;D:\Program Files\Sysload\history\activity;FRLPMSYS01;9502;D:\Program Files\Sysload\history\alert;FRLPMSYS01;9502;C:\Program Files\Sysload\sldrmd\event.ini;C:\Program Files\Sysload\sldrmd\sldrmd.ini;C:\Program Files\Sysload\sldrmd\entity.ini;;C:\Program Files\Sysload\sldrmd\sldrmd.log;

	$mo = @{}
	$mo_array = @()
	
	foreach($line in $lines)
	{
		if(-not $line) # Make sure to ignore blank lines
		{
			continue
		}
		
		$line = $line.split(";")
		
		$agent_type = $line[1]
		$agent_name = $line[2]
		$mo_name = $line[3]
		
		$mo_hashtable = sldms_get_mo_hashtable -agent_type $agent_type -agent_name $agent_name -mo_name $mo_name
		
		$mo_array += $mo_hashtable
		
	}

	$mo_array

} # function sldms_declare_new_mos()

# -----------------------------------------------------------------------------

function illustration_get_mos_from_a_given_mo_group()
{
	param($mo_group_class_name, $mo_group_name)
	
	# Write to the standard output le Managed Objects belonging to the given Managed Object Group
	
	$mos = @()

	$mos = sldms_get_group_mo_list -mo_group_class_name $mo_group_class_name -mo_group_name $mo_group_name
	
	Write-Host
	Write-Host ("MOs for MO Group '{1}' ('{0}'):" -f $mo_group_class_name, $mo_group_name)
	
	$mo_notation = ""
	
	foreach($mo in $mos)
	{
		$mo_notation = $mo.mo_notation
		
		Write-Host $mo_notation
	}
	
}

# -----------------------------------------------------------------------------

function illustration_declare_new_mos()
{

	param($agent_hostids, $agent_port_nos)
	
	# This function declares new Managed Objects from one or more Agents
	
	$mos = @()
	$mos = sldms_declare_new_mos -agent_hostids $agent_hostids -agent_port_nos $agent_port_nos
	
	Write-Host
	Write-Host "MOs added to Management Server:"

	foreach($mo in $mos)
	{
		$mo_notation = $mo.mo_notation
		
		Write-Host $mo_notation
	}

} # function illustration_declare_new_mos()


# -----------------------------------------------------------------------------

function illustration_get_data()
{

	$result = ""

	$url = "http://{0}:{1}/services/{2}/sldapi/api_execute?username={3}&password={4}&method=getagthstdata&agent=NT;vmstm2k870&metric=Processoractivity-Overall-totalCpuuse&instance=&date=2011-06-21&showheader=1&outputformat=csv" -f $ms_host, $ms_port, $ms_service_name, $user_login, $user_password

	$lines = sldms_query -url $url

	foreach($line in $lines)
	{
			write-host $line
	}
	
} # function illustration_get_data()

# -----------------------------------------------------------------------------

# Configure the variables before the "illustration" functions

$mo_group_class_namei = 'category'
$mo_group_namei = 'Product Management'
illustration_get_mos_from_a_given_mo_group -mo_group_class_name $mo_group_class_namei -mo_group_name $mo_group_namei
#
#$agent_hostids = "vmstl53641.orsypgroup.com"
#$agent_port_nos = 9602
#illustration_declare_new_mos -agent_hostids $agent_hostids -agent_port_nos $agent_port_nos
#
illustration_get_data